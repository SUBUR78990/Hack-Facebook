# Paid Tool 

![Made in Pakistan](https://img.shields.io/badge/MADE%20IN%20-PAKISTAN-green?style=for-the-badge&logo=appveyor)

![SYED-ZADA](https://img.shields.io/badge/SYED%20-ZADA-green?style=for-the-badge&logo=appveyor)

![GitHub followers](https://img.shields.io/github/followers/syedzada1100?style=for-the-badge)

# Installation 

```  
[+] PLATFORM 32BIT + 64BIT
[+] PAID COMMANDS
termux-setup-storage
pkg update -y
pkg upgrade -y
pkg install git -y
pkg install python -y
pip install requests
pip install mechanize
pip install bs4
pip install future
rm -rf Crack-Pro
git clone https://github.com/syedzada1100/Crack-Pro.git
cd Crack-Pro
git pull 
python Syed.py
```
 
 
## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
## Follow On Social Media
<p align="center">
<a href="https://www.facebook.com/syedshawaizshah655"><img title="Facebook" src="https://img.shields.io/badge/Facebook-white?style=for-the-badge&logo=facebook"></a>
<a href="https://www.instagram.com/syed_zada1100/"><img title="Instagram" src="https://img.shields.io/badge/INSTAGRAM-purple?style=for-the-badge&logo=instagram"></a>
<a href="https://youtube.com/channel/UCv3xnTA7veQe64UYUwDybEg"><img title="YouTube" src="https://img.shields.io/badge/YOUTUBE-red?style=for-the-badge&logo=YouTube"></a>
<a href="https://github.com/syedzada1100"><img title="Github" src="https://img.shields.io/badge/Github-SYED--ZADA-green?style=for-the-badge&logo=github"></a>
 
